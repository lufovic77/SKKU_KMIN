import random
a=[1,2,3,4,5,6,7,8,9,10]
for i in range(10):
    num=random.randint(1,10000)
    a[i]=num;
print(a)

    
    
    
